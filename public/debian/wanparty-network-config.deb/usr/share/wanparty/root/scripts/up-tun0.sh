#!/bin/bash
#
exec > >(tee -i /var/log/wanparty/up-tun0.log)

/bin/date

## sync date
/usr/sbin/ntpdate -u 10.200.0.1  
#/sbin/hwclock --systohc >>/tmp/up-tun0.log 2>&1

##
## QoS pour tun0
##

## A defaut de mieux pour l'instant, 3 classes (par priorite de paquet),
## chacune faisant un equilibrage de trafic entre les flux.
## Normalement au minimum ca evite qu'un unique flux monopolise la ligne.

echo ""
echo -n "QoS sur tun0 , "
date
## affiche classes
echo "** Anciennes classes tc:"
tc class show dev tun0
tc qdisc show dev tun0

## efface classes et gestionnaires
tc qdisc del dev tun0 root >/dev/null 2>&1

## affiche classes
echo "** Classes tc par defaut:"
tc class show dev tun0
tc qdisc show dev tun0

## root => classes prio : 1:1 1:2 1:3
tc qdisc add dev tun0 root handle 1: prio

## classe 1:1 => gestionnaire sfq 10:
tc qdisc add dev tun0 parent 1:1 handle 10: sfq perturb 10

## classe 1:2 => gestionnaire sfq 20:
tc qdisc add dev tun0 parent 1:2 handle 20: sfq perturb 10

## classe 1:3 => gestionnaire sfq 30:
tc qdisc add dev tun0 parent 1:3 handle 30: sfq perturb 10


## affiche classes
echo "** Nouvelles classes tc:"
tc class show dev tun0  
tc qdisc show dev tun0  

## stats sur les classes

echo "Stats: tc -s qdisc ls dev tun0"
tc -s qdisc ls dev tun0
/root/scripts/up-eth0.sh >/var/log/wanparty/up-tun0-eth0.log 2>&1

echo ""
exit 0
