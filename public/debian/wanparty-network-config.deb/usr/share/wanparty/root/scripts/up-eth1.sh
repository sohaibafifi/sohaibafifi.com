#!/bin/bash
#

##
## QoS pour eth0
##

echo "Pas de regles sur eth1 !"
exit 0
