<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>WAN-RT</title>
<script language="JavaScript">
document.location="https://<?php echo $_SERVER['SERVER_ADDR']; ?>/auth/login.php"
</script>
</head>
<body>
<h2><center><a href="https://<?php echo $_SERVER['SERVER_ADDR']; ?>/auth/login.php">Authentification WAN-RT</a></center></h2>
</body>
</html>
